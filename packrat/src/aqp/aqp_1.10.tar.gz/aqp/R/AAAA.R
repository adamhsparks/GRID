
# setup a new environment to store error messages, etc.
aqp.env <- new.env(hash=TRUE, parent = parent.frame())

